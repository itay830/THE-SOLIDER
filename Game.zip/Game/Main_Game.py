#import package
import pygame, random
pygame.init()

#screen statistics
screen_width, screen_height = 1920, 1080 #with a reason
win = pygame.display.set_mode((screen_width, screen_height), pygame.FULLSCREEN)
pygame.display.set_caption('THE SOLIDER')


#font for texts
font = pygame.font.SysFont('consolas', 50, True)

#images
go_sign = pygame.image.load('go_sign.png')
play_button_img = pygame.image.load('play_button.png').convert_alpha()
main_button_img = pygame.image.load('main_button.png').convert_alpha()

#player animation
walkright = [pygame.image.load('solider_stand_right.png'), pygame.image.load('solider_right_1.png'), pygame.image.load('solider_right_2.png'), pygame.image.load('solider_right_3.png'), pygame.image.load('solider_right_4.png')]
walkleft = [pygame.image.load('solider_stand_left.png'), pygame.image.load('solider_left_1.png'), pygame.image.load('solider_left_2.png'), pygame.image.load('solider_left_3.png'), pygame.image.load('solider_left_4.png')]

#Tilcon
pygame.display.set_icon(walkright[0])

#FPS + Timer
clock = pygame.time.Clock()

#sound effects
bulletsound = pygame.mixer.Sound('gun_shot_sound.wav')
hitsound = pygame.mixer.Sound('hit_sound.mp3')
bone_break_sound = pygame.mixer.Sound('bone_break.mp3')

#bg music
music = pygame.mixer.music.load('bg_music.mp3')
pygame.mixer.music.play(-1)

#starter values
hitboxespass = False
bullet_change = 0
solider_side = -1
change_y = 0
change_x = 0
clear = False
damage_pass_one = True
damage_pass_two = False
about_pass = False
score = 0
level = 0

#player statistics
class player():
    def __init__(self, x, y, width, height):
        self.x = x
        self.y = y
        self.width = width
        self.height = height
        self.vel = 5
        self.isjump = False
        self.jumpPower = 13
        self.left = False
        self.right = False
        self.walkcount = 0
        self.standing = True
        self.hitbox = (self.x + 20, self.y, 28, 60)
        self.damage = 1

    def draw(self, win):
        if self.walkcount + 1 >= 15:
            self.walkcount = 0

        if not(self.standing):
            if self.left:
                win.blit(walkleft[self.walkcount//3], (self.x,self.y))
                self.walkcount += 1
            elif self.right:
                win.blit(walkright[self.walkcount//3], (self.x,self.y))
                self.walkcount += 1
        else:
            if self.right:
                win.blit(walkright[0], (self.x, self.y))
            else:
                win.blit(walkleft[0], (self.x, self.y))
        self.hitbox = (self.x - 8, self.y - 10, self.width + 10, self.height + 20)
        if hitboxespass:
            pygame.draw.rect(win, (255, 0, 0), self.hitbox, 2)

    def hit(self):
        global run, win
        self.isjump = False
        self.jumpPower = 13
        self.x = 300
        self.y = 800
        self.walkcount = 0
        font1 = pygame.font.SysFont('consolas', 100)
        text = font1.render('GAME OVER', 1, (255, 0, 0))
        win.blit(text, ((screen_width // 2 - (text.get_width() / 2)), 200))
        pygame.display.update()
        bone_break_sound.play()
        q = 0
        while q < 300:
            keys = pygame.key.get_pressed()
            pygame.time.delay(10)
            q += 1
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    q = 301
                    pygame.quit()

            if keys[pygame.K_TAB]:
                run = False
        run = False

    def next_level(self):
        global level, slime, ghost, monster, victory_sound
        self.x = self.width + 5
        self.y = 730
        self.isjump = False
        self.jumpPower = 13
        self.walkcount = 0
        level += 1
        if level == 2:

            slime = enemy(600, 680, 300, 300, screen_width - 300, 149, 8)
        elif level == 3:
            pygame.time.delay(500)

#bullet statistics
class bullet_class():
    def __init__(self, x, y, radius, color, facing):
        self.x = x
        self.y = y
        self.radius = radius
        self.color = color
        self.facing = facing
        self.vel = 25 * facing

    def draw(self, win):
        pygame.draw.circle(win, self.color, (self.x, self.y), self.radius)

#enemy
class enemy():
    #ghost animation
    walkright_ghost = [pygame.image.load('enemy_right_1.png'), pygame.image.load('enemy_right_2.png'),pygame.image.load('enemy_right_3.png')]
    walkleft_ghost = [pygame.image.load('enemy_right_1.png'), pygame.image.load('enemy_right_2.png'),pygame.image.load('enemy_right_3.png')]

    #slime animation
    walkright_slime = [pygame.image.load('slime_right_1.png'), pygame.image.load('slime_right_2.png'), pygame.image.load('slime_right_3.png')]
    walkleft_slime = [pygame.image.load('slime_left_1.png'), pygame.image.load('slime_left_2.png'), pygame.image.load('slime_left_3.png')]

    #monster animation
    walkleft_monster = [pygame.image.load('monster_left_1.png'), pygame.image.load('monster_left_2.png')]

    def __init__(self, x, y, width, height, end, health, velocity):
        self.x = x
        self.y = y
        self.width = width
        self.height = height
        self.end = end
        self.path = [1, self.end]
        self.walkcount = 0
        self.vel = velocity
        self.hitbox = (self.x, self.y, self.width, self.height)
        self.health = health
        self.visible = True
        self.isjump = True
        self.jumpPower = 20
        self.neg = -1
        self.timer = 0

    def draw(self, win):
        global level
        if self.visible and level == 1:
            self.move()
            self.hitbox = (self.x + 40, self.y - 10, self.width - 80, self.height - 80)

            if self.walkcount + 1 >= 18:
                self.walkcount = 0
            if self.vel > 0:
                win.blit(self.walkright_ghost[self.walkcount // 6], (self.x, self.y))
                self.walkcount += 1
            else:
                win.blit(self.walkleft_ghost[self.walkcount // 6], (self.x, self.y))
                self.walkcount += 1

            pygame.draw.rect(win, (255,0,0), (self.hitbox[0] + 35, self.hitbox[1] - 50, 90, 20))
            pygame.draw.rect(win, (0,255,0), (self.hitbox[0] + 35, self.hitbox[1] - 50, 90 - (10 * (9 - self.health)), 20))

            if hitboxespass:
                pygame.draw.rect(win, (255, 0, 0), self.hitbox, 2)


        if level == 2 and self.visible:
            self.move()
            self.hitbox = (self.x + 20, self.y + 60, self.width - 50, self.height - 160)
            if self.walkcount + 1 >= 24:
                self.walkcount = 0
            if self.vel > 0:
                win.blit(self.walkright_slime[self.walkcount // 8], (self.x, self.y))
                self.walkcount += 1
            else:
                win.blit(self.walkleft_slime[self.walkcount // 8], (self.x, self.y))
                self.walkcount += 1

            pygame.draw.rect(win, (255,0,0), (self.hitbox[0] + 20, self.hitbox[1] - 20, 150, 20))
            pygame.draw.rect(win, (0,255,0), (self.hitbox[0] + 20, self.hitbox[1] - 20, 150 - (149 - self.health), 20))
            self.jump()
            if hitboxespass:
                pygame.draw.rect(win, (255, 0, 0), self.hitbox, 2)


        if level == 3 and self.visible:
            self.y = 400
            self.hitbox = (self.x, self.y, self.width, self.height)
            if self.walkcount + 1 >= 24:
                self.walkcount = 0
            if self.vel > 0:
                win.blit(self.walkright_monster[self.walkcount // 12], (self.x, self.y))
                self.walkcount += 1
            else:
                win.blit(self.walkleft_monster[self.walkcount // 12], (self.x, self.y))
                self.walkcount += 1

            pygame.draw.rect(win, (255, 0, 0), (50, 100, 1799, 50))
            pygame.draw.rect(win, (0, 255, 0), (50, 100, 1800 - (1799 - self.health), 50))

            if hitboxespass:
                pygame.draw.rect(win, (255, 0, 0), self.hitbox, 2)


    def move(self):
        if self.vel > 0:
            if self.x + self.vel < self.path[1]:
                self.x += self.vel
            else:
                self.vel *= -1
                self.walkcount = 0
        else:
            if self.x - self.vel > self.path[0]:
                self.x += self.vel
            else:
                self.vel *= -1
                self.walkcount = 0

    def jump(self):
        if self.visible and level == 2:
            if self.jumpPower >= -20:
                self.neg = 1
                if self.jumpPower < 0:
                    self.neg = -1
                self.y -= self.jumpPower ** 2 * 0.1 * self.neg
                self.jumpPower -= 1
            else:
                self.jumpPower = 20



    def hit(self):
        if self.health > 0:
            self.health -= solider.damage
        else:
            self.visible = False

#main screen loop
def draw_main_screen():
    pygame.display.update()

class button():
    def __init__(self, x, y, image):
        self.x = x
        self.y = y
        self.image = image
        self.rect = self.image.get_rect()
        self.rect.topleft = (x,y)
        self.click = False

    #"PLAY" button
    def draw_play(self):
        global main_screen, about_pass, level
        mouse_pos = pygame.mouse.get_pos()

        if self.rect.collidepoint(mouse_pos):
            if pygame.mouse.get_pressed()[0] == 1 and self.click == False:
                level = 1
                self.click = True
                main_screen = False
                about_pass = False
        win.blit(self.image, (self.rect.x, self.rect.y))

    #"ABOUT" button
    def draw_about(self):
        global main_screen, about_pass
        mouse_pos = pygame.mouse.get_pos()
        if self.rect.collidepoint(mouse_pos):
            if pygame.mouse.get_pressed()[0] == 1 and self.click == False:
                self.click = True
                about_pass = True
                pygame.time.delay(500)
            elif pygame.mouse.get_pressed()[0] == 1 and self.click == True:
                self.click = False
                about_pass = False
                pygame.time.delay(500)
        win.blit(self.image, (self.rect.x, self.rect.y))

#main screen buttons
play_button = button(screen_width//2 + 100 , 50, play_button_img)
about_button = button(screen_width//2 - 650, 50, main_button_img)

#basic main (home) screen
main_screen = True
while main_screen:
    keys = pygame.key.get_pressed()
    win.fill((0, 0, 0))
    play_button.draw_play()
    about_button.draw_about()
    if about_pass == True:
        text_about = font.render('The game is made by a fourteen year old boy named', 1, (255, 255, 255))
        win.blit(text_about, (screen_width // 2 - 700, 400))

        text_about = font.render('Itay Shinderman from school named Eldad Natania.', 1, (255, 255, 255))
        win.blit(text_about, (screen_width // 2 - 700, 450))

        text_about = font.render('The game is very simple, you just need to kill',1, (255, 255, 255))
        win.blit(text_about, (screen_width // 2 - 700, 500))

        text_about = font.render('all the monsters in your way.',1, (255, 255, 255))
        win.blit(text_about, (screen_width // 2 - 700, 550))

        text_controls = font.render('"Up" arrow key is for jumping, "Left" and "Right" arrow', 1, (255, 255, 255))
        win.blit(text_controls, (screen_width // 2 - 700, 650))

        text_controls = font.render('keys are for moving left and right, "Space" button is for', 1, (255, 255, 255))
        win.blit(text_controls, (screen_width // 2 - 700, 700))

        text_controls = font.render('shooting bullets and finally "Shift" for running.', 1, (255, 255, 255))
        win.blit(text_controls, (screen_width // 2 - 700, 750))

        text_controls = font.render('Press "F3" if you want to see more in-game details.', 1, (255, 255, 255))
        win.blit(text_controls, (screen_width // 2 - 700, 800))

        text_controls = font.render('IDE: PyCharm Community Edition 2021.2.3.', 1, (255, 255, 255))
        win.blit(text_controls, (screen_width // 2 - 700, 900))

    if keys[pygame.K_TAB]:
        run = False
        main_screen = False
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            main_screen = False
            pygame.QUIT
    draw_main_screen()

#main draw function
def game_window():
    global level
    win.blit(bg, (0, 0))
    score_text = font.render('Score: ' + str(score), 1, (255, 255, 255))
    won_text = font.render('YOU WON WITH SCORE OF: ' + str(score) + '. Thank you for playing my game :)', 1, (255, 0, 0))
    won_text2 = font.render('Made by Itay Shinderman', 1, (0, 0, 0))
    damage_text = font.render('STR: ' + str(solider.damage), 1, (255, 255, 255))
    FPS = font.render('FPS: ' + str(clock), 1, (255, 255, 255))
    win.blit(score_text, (screen_width - (screen_width - 25), 200))

    #more information
    if hitboxespass:
        win.blit(damage_text, (screen_width - (screen_width - 25), 250))
        win.blit(FPS, (screen_width - (screen_width - 25), 25))
    if level == 1:
        ghost.draw(win)
        if ghost.visible == False:
            win.blit(go_sign, (500, 50))
    elif level == 2:
        slime.draw(win)
        if slime.visible == False:
            win.blit(go_sign, (500, 50))
    elif level == 3:
        monster.draw(win)
        for monster_bullet in monster_bullets:
            monster_bullet.draw(win)
    else:
        win.blit(won_text, (screen_width // 2 - 800, screen_height // 2))
        win.blit(won_text2, (screen_width // 2 - 800, screen_height // 2 + 100))
    solider.draw(win)
    for bullet in bullets:
        bullet.draw(win)
    pygame.display.update()


#starter statistics
bg = pygame.image.load('bg_game_night.jpg')
solider = player(50, 730, 150, 150)
ghost = enemy(200, 750, 200, 200, 1080, 9, 4)
monster = enemy(screen_width - 500, 680, 500, 500, 0, 1799, 0)
bullet_set = 0
bullet_num = 10
bullets = []
monster_bullets = []

#main loop
run = True
while run and not(main_screen):
    clock.tick(30)

    #contact between player and enemy
    if level == 1 and ghost.visible:
        if solider.hitbox[1] < ghost.hitbox[1] + ghost.hitbox[3] and solider.hitbox[1] + solider.hitbox[3] > ghost.hitbox[1]:
            if solider.hitbox[0] + solider.hitbox[2] > ghost.hitbox[0] and solider.hitbox[0] < ghost.hitbox[0] + ghost.hitbox[2]:
                solider.hit()

    if level == 2 and slime.visible:
        if solider.hitbox[1] < slime.hitbox[1] + slime.hitbox[3] and solider.hitbox[1] + solider.hitbox[3] > slime.hitbox[1]:
            if solider.hitbox[0] + solider.hitbox[2] > slime.hitbox[0] and solider.hitbox[0] < slime.hitbox[0] + slime.hitbox[2]:
                solider.hit()


    if level == 3 and monster.visible:
        if solider.hitbox[1] < monster.hitbox[1] + monster.hitbox[3] and solider.hitbox[1] + solider.hitbox[3] > monster.hitbox[1]:
            if solider.hitbox[0] + solider.hitbox[2] > monster.hitbox[0] and solider.hitbox[0] < monster.hitbox[0] + monster.hitbox[2]:
                solider.hit()

        #monster bullets
        for monster_bullet in monster_bullets:
            if monster.visible:
                if monster_bullet.y - monster_bullet.radius < solider.hitbox[1] + solider.hitbox[3] and monster_bullet.y + monster_bullet.radius > solider.hitbox[1]:
                    if monster_bullet.x + monster_bullet.radius > solider.hitbox[0] and monster_bullet.x - monster_bullet.radius < solider.hitbox[0] + solider.hitbox[2]:
                        monster_bullets.pop(monster_bullets.index(monster_bullet))
                        solider.hit()
            if monster.health > 1000:
                if monster_bullet.x < 1920 and monster_bullet.x > 0:
                    if monster.health > 1450:
                        monster_bullet.x += monster_bullet.vel
                    else:
                        monster_bullet.x += monster_bullet.vel - 5
                        bullet_change = 2
                else:
                    monster_bullets.pop(monster_bullets.index(monster_bullet))
            elif monster_bullet.y < 1000 and monster_bullet.y > 0:
                monster_bullet.y -= monster_bullet.vel
                if not(clear):
                    monster_bullets = []
                    clear = True
            else:
                monster_bullets.pop(monster_bullets.index(monster_bullet))

        if len(monster_bullets) < 2 + bullet_change and monster.health > 1000:
            monster_bullets.append(bullet_class(round(monster.x + monster.width // 2), round(monster.y + monster.height // 1.5), 60, (185, 74, 0), -1))
        elif len(monster_bullets) < 3 + bullet_change and monster.health <= 1000:
            bullet_change = 0
            change_x = random.randrange(10, 1920)
            monster_bullets.append(bullet_class(change_x, 80, 20, (255, 0, 0), -1))
            if monster.health <= 700:
                bullet_change += 1
                change_x = random.randrange(10, 1920)
                monster_bullets.append(bullet_class(change_x, 80, 20, (0, 255, 0), -1))
            if monster.health <= 300:
                bullet_change += 2
                change_x = random.randrange(10, 1920)
                monster_bullets.append(bullet_class(change_x, 80, 20, (0, 0, 255), -1))

    #win
    if level == 3 and monster.visible == False:
        pygame.mixer.music.stop()
        music = pygame.mixer.music.load('issac_legendery_dance.wav')
        pygame.mixer.music.play(-1)
        bullets = []
        bullet_num = -1
        level = 4

    #limits
    if bullet_set > 0:
        bullet_set += 1
    if bullet_set > 3:
        bullet_set = 0

    #contact between bullet and enemy
    if level == 1:
        for bullet in bullets:
            if ghost.visible:
                if bullet.y - bullet.radius < ghost.hitbox[1] + ghost.hitbox[3] and bullet.y + bullet.radius > ghost.hitbox[1]:
                    if bullet.x + bullet.radius > ghost.hitbox[0] and bullet.x - bullet.radius < ghost.hitbox[0] + ghost.hitbox[2]:
                        hitsound.play()
                        ghost.hit()
                        score += 10 * solider.damage
                        bullets.pop(bullets.index(bullet))
            if bullet.x < screen_width and bullet.x > 0:
                bullet.x += bullet.vel
            else:
                bullets.pop(bullets.index(bullet))
                score -= 10

    elif level == 2:
        for bullet in bullets:
            if slime.visible:
                if bullet.y - bullet.radius < slime.hitbox[1] + slime.hitbox[3] and bullet.y + bullet.radius > slime.hitbox[1]:
                    if bullet.x + bullet.radius > slime.hitbox[0] and bullet.x - bullet.radius < slime.hitbox[0] + slime.hitbox[2]:
                        hitsound.play()
                        slime.hit()
                        score += 10 * solider.damage
                        bullets.pop(bullets.index(bullet))
                        slime.vel += 0.07 * solider.damage
            if bullet.x < screen_width and bullet.x > 0:
                bullet.x += bullet.vel
            else:
                bullets.pop(bullets.index(bullet))
                score -= 10


    elif level == 3:
        for bullet in bullets:
            if monster.visible:
                if bullet.y - bullet.radius < monster.hitbox[1] + monster.hitbox[3] and bullet.y + bullet.radius > monster.hitbox[1]:
                    if bullet.x + bullet.radius > monster.hitbox[0] and bullet.x - bullet.radius < monster.hitbox[0] + monster.hitbox[2]:
                        hitsound.play()
                        monster.hit()
                        score += 10 * solider.damage
                        bullets.pop(bullets.index(bullet))
            if bullet.x < screen_width and bullet.x > 0:
                bullet.x += bullet.vel
            else:
                bullets.pop(bullets.index(bullet))
                score -= 10

    #controls
    keys = pygame.key.get_pressed()
    if keys[pygame.K_TAB]:
        run = False
    if keys[pygame.K_SPACE] and bullet_set == 0:
        if solider.left:
            solider_side = -1
        elif solider.right:
            solider_side = 1
        if len(bullets) < bullet_num:
            bulletsound.play()
            if solider_side == -1:
                bullets.append(bullet_class(round(solider.x - 40 + solider.width // 4), round(solider.y - 15 + solider.height // 2), 6, (255,0,0), solider_side))
            if solider_side == 1:
                bullets.append(bullet_class(round(solider.x + 120 + solider.width // 4), round(solider.y - 15 + solider.height // 2), 6, (255,0,0), solider_side))
        bullet_set = 1

    if keys[pygame.K_F3]:
        pygame.time.delay(200)
        if hitboxespass:
            hitboxespass = False
        else:
            hitboxespass = True

    if keys[pygame.K_LSHIFT]:
        solider.vel = 15
    else:
        solider.vel = 5
    if keys[pygame.K_LEFT] and solider.x > solider.vel:
        solider.x -= solider.vel
        solider.right = False
        solider.left = True
        solider.standing = False

    elif keys[pygame.K_RIGHT] and solider.x < screen_width - solider.width - solider.vel:
        solider.x += solider.vel
        solider.right = True
        solider.left = False
        solider.standing = False
        if level == 1 and solider.x > screen_width - 250 and ghost.visible == False:
            solider.next_level()

        elif level == 2 and solider.x > screen_width - 250 and slime.visible == False:
            solider.next_level()
    else:
        solider.standing = True
        solider.walkcount = 0

    if not(solider.isjump):
        if keys[pygame.K_UP]:
            solider.isjump = True
            solider.walkcount = 0
    else:
        if solider.jumpPower >= -13:
            neg = 1
            if solider.jumpPower < 0:
                neg = -1
            solider.y -= (solider.jumpPower ** 2) / 2 * neg
            solider.jumpPower -= 1
        else:
            solider.isjump = False
            solider.jumpPower = 13


    #Damage multiplayer
    if score >= 350 and damage_pass_one:
        solider.damage += 4
        damage_pass_two = True
        damage_pass_one = False
    elif score >= 5000 and damage_pass_two:
        solider.damage += 5
        damage_pass_two = False
    if score <= -300:
        solider.hit()

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            run = False

    #update game window
    game_window()

#finish project
pygame.quit()